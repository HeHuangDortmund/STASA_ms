## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- out.width = "500px"-----------------------------------------------------
filepath = system.file('stimulus/shorttimeAOI3D2D.png', package = "scanpathAggr")
knitr::include_graphics(filepath)

## -----------------------------------------------------------------------------
library(scanpathAggr)

## -----------------------------------------------------------------------------
data(scanpath_MIT1003_i1182314083)
reprensentScanpath = scanpathAggr(scanpath_MIT1003_i1182314083, 3, theta = 0.2)

## -----------------------------------------------------------------------------
data(scanpath_OSIE_1001)
reprensentScanpath = scanpathAggr(scanpath_MIT1003_i1182314083, 3, theta = 0.2)

## ---- out.width = "700px", , out.height="400px"-------------------------------
reprensentScanpath = scanpathAggr(scanpath_MIT1003_i1182314083, 3, theta = 0.2)
stimuluspath = system.file('stimulus/i1182314083.jpeg', package = "scanpathAggr")
scanpathVisualisation(scanpath_MIT1003_i1182314083, reprensentScanpath, stimuluspath)

## ---- out.width = "700px", , out.height="400px"-------------------------------
data(scanpath_MIT1003_i1182314083)
reprensentScanpath = scanpathAggr(scanpath_MIT1003_i1182314083, 3, theta = 0.6)
scanpathVisualisation(scanpath_MIT1003_i1182314083, reprensentScanpath, stimuluspath)

## ---- out.width = "700px", , out.height="400px"-------------------------------
data(scanpath_MIT1003_i1182314083)
reprensentScanpath = scanpathAggr(scanpath_MIT1003_i1182314083, 3, theta = 0.2, simplify = TRUE)
scanpathVisualisation(scanpath_MIT1003_i1182314083, reprensentScanpath, stimuluspath)

