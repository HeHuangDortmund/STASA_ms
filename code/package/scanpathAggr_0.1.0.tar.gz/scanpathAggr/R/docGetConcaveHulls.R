#' Scanpath Aggregation Package
#'
#' Calculate concave hulls on each cross section
#'
#' @docType package
#'
#' @author He Huang
#'
#' @name getConcaveHulls
NULL
