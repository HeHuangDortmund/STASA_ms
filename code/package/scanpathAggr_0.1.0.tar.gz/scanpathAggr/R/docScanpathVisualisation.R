#' Scanpath Aggregation Package
#'
#' Scanpath Visualisation
#'
#' @docType package
#'
#' @author He Huang
#'
#' @name scanpathVisualisation
NULL
