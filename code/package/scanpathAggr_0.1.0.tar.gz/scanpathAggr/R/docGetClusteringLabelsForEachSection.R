#' Scanpath Aggregation Package
#'
#'  clutering the cross sections and get clustering labels for each cross section
#'
#' @docType package
#'
#' @author He Huang
#'
#' @name getClusteringLabelsForEachSection
NULL
